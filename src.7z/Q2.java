public class Q2 {
    //The implementation of the PredatoryCreditCard.charge method is flawed because it calls
    // the charge method recursively within itself without any condition to stop the recursion.
    // This can lead to an infinite loop and eventually result in a stack overflow error.
    //Additionally, the implementation includes a penalty charge of 5 units if the initial charge fails.
    // However, it does not check if the penalty charge is successful or not,
    // and it always returns the value of isSuccess without considering the penalty charge.
    //To fix this implementation, you should add a condition to stop the recursion and also
    // check if the penalty charge is successful before returning the final result.
}



