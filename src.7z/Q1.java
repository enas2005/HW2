public class Q1 {
    //The implementation of the charge method in the PredatoryCreditCard class is flawed because it directly calls the
    // charge method of the superclass (`CreditCard`) without checking the balance of the credit card. This means that
    // even if the balance is insufficient to cover the charge, the charge method will still return true and the penalty charge of 5 will be applied.
    //To fix this issue, the PredatoryCreditCard class should use the getBalance method (if available) or introduce a new method in the CreditCard class
    // that allows accessing the balance. Then, the PredatoryCreditCard class can use this method to check the balance before deciding whether to apply
    // the penalty charge or not
}
