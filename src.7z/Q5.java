public class Q5 {
    //two interfaces cannot mutually extend each other. This is because Java interfaces follow a strict hierarchy
    // where an interface can extend another interface, but it cannot extend multiple interfaces simultaneously.
}
