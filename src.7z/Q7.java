public class Q7 {
    //The presence of a very shallow inheritance in the Java language,
    // where all groups extend only one category, can have some potential competence defects:
    //1. A limited ability to reuse the code
    //2. Reducing flexibility
    //3. Increased interconnection
    //4. Reducing pluralism
    //5. Increased performance
    //
}
