public class FibonacciProgression {
    public FibonacciProgression(int i, int i1) {
    }
    private void advance(int i) {
    }

    public static void main(String[] args) {
        FibonacciProgression fibonacciProgression = new FibonacciProgression(2, 2);
        fibonacciProgression.advance(7);
        long eighthValue = fibonacciProgression.getCurrent();
        System.out.println("The eighth value of the Fibonacci progression is: " + eighthValue);

    }

    long getCurrent() {
        return 0;
    }


    public void advance(){
}
}