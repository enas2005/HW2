public class Q10 {
    //Yes, you are correct. In the given class hierarchy, if d refers to an actual object of type Equestrian,
    // it cannot be cast to the class Racer.
    //The reason is that Racer is a subclass of Horse, while Equestrian is also a subclass of Horse.
    // However, Racer and Equestrian are not directly related to each other in the class hierarchy.
    //In Java, you can only cast an object to a class that it is either an instance of or a subclass of.
    // Since Equestrian is not a subclass of Racer, you cannot cast Racer.
}
