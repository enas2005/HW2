public class Q6 {
    //Having very deep inheritance trees in Java can lead to several potential efficiency disadvantages:
    //1. Increased Complexity
    //2. Reduced Flexibility
    //3. Performance Overhead
    //4. Increased Memory Usage
    //5. Increased performance
}
