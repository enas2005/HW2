public class Q8 {
   //"Read it."
    //"Box it."
    //"Buy it."
    //"Read it."
    //"Buy it."
    //"Read it."
}
